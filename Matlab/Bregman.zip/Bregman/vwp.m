%This Function perfroms AVWP as described in CAM (08-81)
%
%The Function expects the following parameter:
%
%
%vwp(panimage, lowres, gamm, iter, epsi, waveletname,
%quotparam,matchingcoef, lowresweight, eta, lambda)
%
%   panimage: high resolution panchromatic image
%
%   lowres: low resolution multispectral image, which has already been
%   upsampled so that it has exactly the same size as paniamge
%
%   gamm is the parameter for the TV part of the geometry matching term
%
%   iter is the maximum number of iterations in gradient descent
%
%   epsitheta is the regularization parameter for the calculation of theta
%
%   waveletname is the wavelet that is used
%
%   quotparam: Parameter for a term that enforforces the ratios of all 
%   combinations of different bands to stay constant
%
%   matchingcoef is the parameter for the fidelity term
%   
%   lowresweight is a parameter that influences what we want to call an edge
%
%   eta is the parameter for the theta part of the geometry matching term
%
%   lambda is the parameter from the Split Bregman method

function solution = vwp(panimage, lowres, gamm, iter, epsi, waveletname, quotparam, matchingcoef, lowresweight, eta, lambda)
close all;

%the followong code checks if all parameters exist. If not it assigns
%default values to them.
if ~exist('matchingcoef')
    matchingcoef = 2;
end
if ~exist('coeffparam')
    lowresweight = 10;
end

if ~exist('quotparam')
    quotparam = 200;
end
if ~exist('waveletname')
    waveletname = 'sym4';
end
if ~exist('epsi')
    epsitheta = 5*10^(-3);
end
if ~exist('iter')
    iter = 100;
end
if ~exist('gamm')
    gamm =1;
end
if ~exist('eta')
    eta =1;
end
if ~exist('lowres')
    load('exampledata.mat');
end
if ~exist('lambda')
    lambda = 10*matchingcoef;
end


[n m c] = size(lowres);
%multispectral images are usually on a weird scale which is why we norm
%each band to have values between 0 and 1. This also seems to give the most
%reasonable color images when we display the lowres.
lowres = double(lowres);
panimage = double(panimage);
for i=1:c
    fac(i) = max(max(lowres(:,:,i)));
    lowres(:,:,i) = lowres(:,:,i)/fac(i);
end
panimage = panimage/max(max(panimage));

%show initial images
figure, imshow(panimage), title('high resolution panchromatic image');
figure, imshow(lowres(:,:,1:3)), title('Low resolution image');

%measure runtime
tic

%Unfortunately the stationary wavelet decomposition requires the image to 
%meet that 2^(level of decomposition) must divide size(X,1) and size(X,2)
%for an image X. 
%We therefore extend images to the size needed for stationary wavelet 
%decomposition simply by adding zero collums and rows. 
level = 2;
div = double(2^level);
if (ceil(n/div)*div ~= n)
    adcol = ceil(n/div)*div - n;
    temp1 = zeros(adcol, m, c);
    temp2 = zeros(adcol, m, 1);
    lowres = [lowres; temp1];
    panimage = [panimage; temp2];
end
[n2 m2 c2] = size(lowres);
if (ceil(m/div)*div ~= m2)
    adrow = ceil(m2/div)*div - m2;
    temp1 = zeros(n2, adrow, c2);
    temp2 = zeros(n2, adrow, 1);
    lowres = [lowres temp1];
    panimage = [panimage temp2];
end
    
%calculate stationary wavelet decomposition of the panchromatic image
temp = swt2(panimage,level,waveletname);
apprnumber = 3*level+1;
%calculate stationary wavelet decomposition of each multispectral band and
%produce a wavelet fused image
for i=1:c
    temp2 = swt2(lowres(:,:,i), level, waveletname);
    matchingwavelets = temp;
    matchingwavelets(:,:,apprnumber) = temp2(:,:,apprnumber);
    wavefusedimage(:,:,i) = iswt2(matchingwavelets, waveletname);
end
%go back to original image sizes
wavefusedimage = wavefusedimage(1:n,1:m,:);
lowres = lowres(1:n,1:m,:);
panimage = panimage(1:n,1:m,:);

%Calculate the edgeset needed for matching away from the edges:
nom = (sqrt(imfilter(panimage, [-1 1 0], 'replicate', 'same').^2+imfilter(panimage, [-1 1 0]', 'replicate', 'same').^2 + 0.0001.^2)).^2*8000;
nonedgeset = (1-exp(-3.314*lowresweight*ones(n,m)./nom)).^2;
%show the edgeset
figure, imshow(nonedgeset), title('Edgeset');
edgeset = 1 - nonedgeset;


%Create matching image as combination of lowres and wavelet fused image:
for k=1:c
    matchingimage(:,:,k) = nonedgeset.*lowres(:,:,k) +  edgeset .* wavefusedimage(:,:,k);
end

%initialize vector field theta
thetapan = theta2(panimage, epsitheta);
divertheta = imfilter(thetapan(:,:,1), [0 -1 1], 0, 'same') + imfilter(thetapan(:,:,2), [0 -1 1]', 0, 'same'); 

%Do energy minimization:
solution = bregmanmin(lowres, matchingimage, matchingcoef, quotparam, iter, divertheta, eta, lambda, gamm);

%stop runtime
toc

%show result
figure, imshow(solution(:,:,1:3), title('AVWP restored image'));

%Undo the normalization process
for i=1:c
    solution(:,:,i) = solution(:,:,i)*fac(i);
end