function shrinkisoTV = shrinkisoTV(solution, b, lambda, gamma);
xtemp = imfilter(solution, [0 -1 1], 'replicate', 'same')+b(:,:,1);
ytemp = imfilter(solution, [0 -1 1]', 'replicate', 'same')+ b(:,:,2);
s = sqrt(xtemp.^2 + ytemp.^2);
sreg = s + 10^(-10)*(s==0);
maxi = max(s - gamma/lambda,0);
shrinkisoTV(:,:,1) = maxi.* xtemp./sreg;
shrinkisoTV(:,:,2) = maxi.* ytemp./sreg;
