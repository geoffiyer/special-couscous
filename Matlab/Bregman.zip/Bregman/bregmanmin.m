function solution = bregmanmin(lowres, matchingimage, matchingcoef, quotparam, iter, divertheta, eta, lambda, gamma)


%initialize everything, precompute constant terms
solution = matchingimage;
[I,J,c]=size(lowres);
tempvar = sum(lowres.^2,3);
for i=1:c
    temp(:,:,i) = tempvar - lowres(:,:,i).^2;
    constpart(:,:,i) = 2 * matchingcoef * matchingimage(:,:,i) - eta * divertheta;
end
diago = 2*quotparam*temp + 2*matchingcoef + 4*lambda*gamma;
b = zeros(I,J,2,c);
d = zeros(I,J,2,c);
summ = sum(solution.*lowres,3);

%actual minimization
for k=1:iter
    %we can set a stopping criterion by looking at the change per
    %iteration. Therefore we save the previous iteration here:
    presolution = solution;
    
    db = d-b;
    for i=1:c
        diverdb =  -(imfilter(db(:,:,1,i), [-1 1 0], 'replicate', 'same') + imfilter(db(:,:,2,i), [-1 1 0]', 'replicate', 'same'));
        summ = summ - lowres(:,:,i).*solution(:,:,i);
        summe = summ .* lowres(:,:,i);    
        q = (constpart(:,:,i) + 2 * quotparam * summe + lambda* diverdb);
        
        %Calculate the solution of the linear equation with Gauss Seidel (here just one swipe):
        for t=1:1
        %This would be a Jakobi solver:
        %solution(:,:,i) = (q + lambda *gamma* imfilter(solution(:,:,i), [0 1 0; 1 0 1; 0 1 0], 'replicate', 'same'))./diago(:,:,i);
         for ih=2:I-1
             for j=2:J-1
             solution(ih,j,i) = (q(ih,j) + lambda *gamma*(solution(ih,j-1,i)+solution(ih,j+1,i)+solution(ih-1,j,i)+solution(ih+1,j,i)))/diago(ih,j,i);
             end
             solution(ih,1,i) = (q(ih,1) + lambda *gamma*(solution(ih,1,i)+solution(ih,2,i)+solution(ih-1,1,i)+solution(ih+1,1,i)))/diago(ih,1,i);
             solution(ih,J,i) = (q(ih,J) + lambda *gamma*(solution(ih,J-1,i)+solution(ih,J,i)+solution(ih-1,J,i)+solution(ih+1,J,i)))/diago(ih,J,i);
         end
         for j=2:J-1
             solution(1,j,i) = (q(1,j) + lambda *gamma*(solution(1,j-1,i)+solution(1,j+1,i)+solution(1,j,i)+solution(2,j,i)))/diago(1,j,i);
             solution(I,j,i) = (q(I,j) + lambda *gamma*(solution(I,j-1,i)+solution(I,j+1,i)+solution(I-1,j,i)+solution(I,j,i)))/diago(I,j,i);
         end
         solution(1,1,i) = (q(1,1) + lambda *gamma*(2*solution(1,1,i)+solution(1,2,i)+solution(2,1,i)))/diago(1,1,i);
         solution(1,J,i) = (q(1,J) + lambda *gamma*(solution(1,J-1,i)+2*solution(1,J,i)+solution(2,J,i)))/diago(1,J,i);
         solution(I,1,i) = (q(I,1) + lambda *gamma*(solution(I,2,i)+solution(I-1,1,i)+2*solution(I,1,i)))/diago(I,1,i);
        solution(I,J,i) = (q(I,J) + lambda *gamma*(solution(I,J-1,i)+2*solution(I,J,i)+solution(I-1,J,i)))/diago(I,J,i);
         
        %update d by generalized shrinkage
         d(:,:,:,i) = shrinkisoTV(solution(:,:,i),  b(:,:,:,i), lambda, gamma);
        end
         
        %update b
         b(:,:,1,i) = b(:,:,1,i) + (gamma*imfilter(solution(:,:,i), [0 -1 1], 'replicate', 'same') - d(:,:,1,i));
         b(:,:,2,i) = b(:,:,2,i) + (gamma*imfilter(solution(:,:,i), [0 -1 1]', 'replicate', 'same') - d(:,:,2,i));
         
         %for spectral correlation preserving term
        summ = summ + lowres(:,:,i).*solution(:,:,i);
    end
    
    %calculate the average change per pixel in the last
    %iteration for a stopping criterion
    dec(k) = sum(sum(sum(abs(solution - presolution))))/ [I*J*c]; 
    if (dec(k)<=10^(-4))
        break;
    end
end

%show how the residual got smaller:
figure, plot(dec), title('decay of the residual');
