%This function calculates the field of vectors perpendicular to the level
%sets of an image. The vectors are (almost) unit normal vectors. 

function theta = theta(img, eps)

grad_img(:,:,1) = imfilter(img, [-1 1 0], 'replicate', 'same');%rwdiff_x(img); 
grad_img(:,:,2) = imfilter(img, [-1 1 0]', 'replicate', 'same');%rwdiff_y(img);
[n m] = size(img);

norm_grad_img = sqrt(grad_img(:,:,1).^2 + grad_img(:,:,2).^2+eps.^2*ones(n,m));

theta(:,:,1) = grad_img(:,:,1)./norm_grad_img;
theta(:,:,2) = grad_img(:,:,2)./norm_grad_img;

