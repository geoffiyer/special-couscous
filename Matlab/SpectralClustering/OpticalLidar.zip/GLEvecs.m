%% Load the data
A = load('DFC/DFC2015.mat');

% Set up some variables. Here X1 = dataset1, X2 = dataset2.

% The rest of the variables allow you to pick a subsection of the image
% to perform the work on (I used this to run tests on smaller images.
% Now that the code is more optimized it's not so necessary)
startrow = 1;
nrow = size(A.im,1);
rowvals = startrow : (startrow + nrow - 1);
startcol = 1;
ncol = size(A.im,2);
colvals = startcol : (startcol + ncol - 1);
X1 = reshape(A.im(rowvals,colvals,:),[nrow*ncol 3])';
X2 = reshape(A.lidar(rowvals,colvals), [nrow*ncol 1])';
[nrx1, ncx1] = size(X1);
[nrx2, ncx2] = size(X2);


%% My unoptimized code for creating the GL, getting Evals and Evecs 
% Don't want to use this anymore

% W = zeros(ncx1,ncx1);   % Weight matrix
% for i = 1:ncx1
%     for j = (i+1):ncx1
%         W(i,j) = exp(-1*max( norm(X1(:,i)-X1(:,j)), 4*norm(X2(:,i)-X2(:,j))  ) );
%         W(j,i) = W(i,j);
%     end
% end

% Deg = diag(sum(W,2));
% L = eye(ncx1) - Deg^(-1/2)*W*Deg^(-1/2); % Graph Laplacian
% [V,D] = eigs(L,8,'sm');     % Eigenvalues/Eigenvectors of Graph Laplacian

%% Using Nystrom method for getting Evecs

rng(0);     % Set random seed for reproducibility

m = 3*floor(sqrt(sqrt(ncx1)));  % number of landmark points. m << Number of Data Points
sigma = 1;                      % scaling parameter. weight = exp( -||x|| / sigma);
kernel = struct('type','rbf','para',sigma);     % setup for INys function
V = INys_SpectrEmbed(X1',X2',kernel,m);         % V = first m eigenvectors of the graph laplacian

%% Display some results.

nevecs = 20;            % number of eigenvectors to store inside I
nevecsToDisplay = 3;    % number of eigenvectors to display

I = reshape(V(:,2:(nevecs+1)),[nrow ncol nevecs]);
I = I ./ max(max(I));
figure
imshow(A.im(rowvals,colvals,:));
title('Original Optical Image');
figure
imshow(A.lidar(rowvals,colvals));
title('Original Lidar Image');

for i = 1:nevecsToDisplay
    figure
    imshow(I(:,:,i));
    title(strcat('Eigenvector number ',num2str(i)))
end